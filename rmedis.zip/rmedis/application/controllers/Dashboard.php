<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged_in') != true) {
            $url = base_url('login');
            redirect($url);
        };
    }
    function index()
    {
        $data = array(
            'title' => 'Administrator',
            'conten' => 'v_dashboard',
        );
        $this->load->view('layout/wrapper', $data);
    }
}
