<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pasien extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged_in') != true) {
            $url = base_url('login');
            redirect($url);
        };
    }
    function index()
    {
        $data = array(
            'title' => 'Administrator',
            'datapasien' => $this->db->query('Select*From tbl_pasien order by id_pasien')->result(),
            'conten' => 'v_pasien_admin',
        );
        $this->load->view('layout/wrapper', $data);
    }


    public function simpan()
    {
        $nama = $this->input->post('nama');
        $tglahir = $this->input->post('tgllahir');
        $jnsk = $this->input->post('jenis_k');
        $alamat = $this->input->post('alamat');
        $simpan = $this->db->query("INSERT INTO tbl_pasien 
								  (nama_pasien,jenis_k,alamat,tgl_lahir)values('$nama','$jnsk','$alamat','$tglahir')");
        redirect('pasien');
    }
    public function hapus($id)
    {
        $hapus = $this->db->query(" DELETE FROM  tbl_pasien WHERE id_pasien='$id' ");
        redirect('pasien');
    }

    public function edit($id)
    {
        $data['data'] = $this->db->query(" SELECT* FROM  tbl_tentangkami WHERE id_tk='$id' ")->row();
        $this->load->view('edit_tentangkami', $data);
    }

    public function update($id)
    {
        $nama = $this->input->post('nama');
        $tglahir = $this->input->post('tgllahir');
        $jnsk = $this->input->post('jenis_k');
        $alamat = $this->input->post('alamat');
        $simpan = $this->db->query("UPDATE tbl_pasien  set nama_pasien='$nama', jenis_k='$jnsk',alamat='$alamat',tgl_lahir='$tglahir'
								  WHERE id_pasien='$id'");
        redirect('pasien');
    }
}
