<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="user-pro"> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)"
                        aria-expanded="false"><img src="<?= base_url() ?>assets/images/users/admin.png" alt="user-img"
                            class="img-circle"><span class="hide-menu">Admin</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="javascript:void(0)"><i class="ti-user"></i>Profil Admin</a></li>
                        <li><a href="javascript:void(0)"><i class="ti-settings"></i> Account Setting</a></li>
                        <li><a href="<?= base_url() ?>home"><i class="fa fa-power-off"></i> Logout</a></li>
                    </ul>
                </li>
                <li> <a class="waves-effect waves-dark" href="<?= base_url() ?>dashboard"><i
                            class="icon-speedometer"></i><span class="hide-menu">Dashboard</span></a>
                </li>


                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i
                            class="ti-calendar"></i><span class="hide-menu">Data Pasien</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="<?= base_url() ?>pasien">Data Pasien</a></li>
                        <li><a href="book-appointment.html">Riwayat</a></li>
                    </ul>
                </li>
                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i
                            class="fa fa-user-md"></i><span class="hide-menu">Dokter</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="doctors.html">Semua Dokter</a></li>
                        <li><a href="add-doctor.html">Tambah Dokter</a></li>
                        <li><a href="edit-doctor.html">Edit Dokter</a></li>
                        <li><a href="doctor-profile.html">Profil Dokter</a></li>
                    </ul>
                </li>
                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i
                            class="icon-people"></i><span class="hide-menu">Rekamedis</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="patients.html">Data Pasien</a></li>
                        <li><a href="add-patient.html">Tambah Pasien</a></li>
                        <li><a href="edit-patient.html">Edit Pasien</a></li>
                    </ul>
                </li>
                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i
                            class="icon-chart"></i><span class="hide-menu">Reports</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="payment-report.html">Payment Report</a></li>
                        <li><a href="income-report.html">Income Report</a></li>
                        <li><a href="sales-report.html">Sales Report</a></li>
                    </ul>
                </li>
                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i
                            class="fa fa-inr"></i><span class="hide-menu">Laporan</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="payments.html">Payments</a></li>
                        <li><a href="add-payments.html">Add Payment</a></li>
                        <li><a href="patient-invoice.html">Invoice</a></li>
                    </ul>
                </li>
                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i
                            class="fa  fa-users"></i><span class="hide-menu">Pengguna</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="payments.html">Payments</a></li>
                        <li><a href="add-payments.html">Add Payment</a></li>
                        <li><a href="patient-invoice.html">Invoice</a></li>
                    </ul>
                </li>

                <li> <a class="waves-effect waves-dark" href="<?= base_url() ?>login/logout"><i
                            class="fa fa-sign-out"></i><span class="hide-menu">Keluar</span></a>
                </li>

            </ul>
        </nav>

    </div>
</aside>